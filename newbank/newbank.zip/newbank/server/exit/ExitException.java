package newbank.server.exception.exit;public class ExitException {
}
